import React from "react";

function App() {
  return (
    <div className="text-center text-3xl font-bold text-purple-600 mt-10">
      Welcome to Ubaid's Portfolio!
    </div>
  );
}

export default App;
